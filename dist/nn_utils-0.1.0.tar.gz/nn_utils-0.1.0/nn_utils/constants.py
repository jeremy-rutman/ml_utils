__author__ = 'jeremy'
min_image_area=100
min_bb_to_image_area_ratio=0.01
ultimate_21=None
fashionista_categories_augmented=None